# Database Schema (V1, PostgreSQL)

Aligns with DOMAIN_MODEL.md: **GenealogyGraph is the sole aggregate root**. Database enforces HARD invariants where feasible; SOFT invariants are validated in the application layer. Schema is optimized for tree reconstruction (ancestor/descendant traversals) within 500–5,000 nodes.

## Tables

### 1) family_trees
```
family_trees (
  tree_id         text        primary key,
  root_person_id  text        null,
  created_at      timestamptz not null default now(),
  created_by      text        null
);
```
Constraints:
- `root_person_id` FK → persons(person_id, tree_id) DEFERRABLE INITIALLY DEFERRED (allows root switch within txn).

Indexes:
- PK on (tree_id).
- FK on (root_person_id, tree_id) with deferrable clause.

### 2) persons
```
persons (
  person_id   text not null,
  tree_id     text not null,
  name        text not null,
  gender      text not null check (gender in ('MALE','FEMALE','UNKNOWN')),
  birth_date  date null,
  birth_place text null,
  death_date  date null,
  primary key (tree_id, person_id),
  foreign key (tree_id) references family_trees(tree_id) on delete cascade,
  check (length(name) > 0 and length(name) <= 255),
  check (death_date is null or birth_date is null or death_date > birth_date)
);
```
Constraints mapped to HARD invariants:
- Identity non-empty, name length, gender validity: CHECKs.
- Death after birth when both present: CHECK.
- Person uniqueness within tree: PK (tree_id, person_id).

Indexes:
- PK (tree_id, person_id) supports graph lookups and FK joins.
- B-tree on (tree_id, name) for person search.
- Optional: trigram index on name for fuzzy find (not required for v1).

### 3) relationships
```
relationships (
  relationship_id bigserial primary key,
  tree_id         text not null,
  relation_type   text not null check (relation_type in ('PARENT_CHILD','SPOUSE')),
  parent_id       text null,
  child_id        text null,
  spouse1_id      text null,
  spouse2_id      text null,
  foreign key (tree_id) references family_trees(tree_id) on delete cascade,
  foreign key (tree_id, parent_id) references persons(tree_id, person_id) on delete cascade,
  foreign key (tree_id, child_id)  references persons(tree_id, person_id) on delete cascade,
  foreign key (tree_id, spouse1_id) references persons(tree_id, person_id) on delete cascade,
  foreign key (tree_id, spouse2_id) references persons(tree_id, person_id) on delete cascade,
  -- Type-specific shape
  check (
    case relation_type
      when 'PARENT_CHILD' then parent_id is not null and child_id is not null and spouse1_id is null and spouse2_id is null and parent_id <> child_id
      when 'SPOUSE' then spouse1_id is not null and spouse2_id is not null and parent_id is null and child_id is null and spouse1_id <> spouse2_id
      else false
    end
  )
);
```
Constraints mapped to HARD invariants:
- Relationship type validity and shape: CHECK.
- No self-relationships: CHECK (`parent_id <> child_id`, `spouse1_id <> spouse2_id`).
- Referential integrity to persons within same tree: FKs.

Uniqueness (HARD):
- Parent-child uniqueness per edge: `unique(tree_id, parent_id, child_id) where relation_type = 'PARENT_CHILD'` (partial unique index).
- Spouse uniqueness per pair (unordered): represent canonically by storing min/max order OR enforce both directions uniqueness. Use canonical ordering at write layer plus unique index:
  - Application stores spouse1_id = least(personA, personB), spouse2_id = greatest(personA, personB).
  - DB: `unique(tree_id, spouse1_id, spouse2_id) where relation_type = 'SPOUSE'`.

Parent count (HARD) — DB-level option:
- Implement via DEFERRABLE CONSTRAINT TRIGGER on `relationships` to enforce `count(parent_id) <= 2` per child within a tree for `relation_type='PARENT_CHILD'`. (Native CHECK/UNIQUE cannot express "<= 2" across rows.) This trigger runs AFTER INSERT/UPDATE, DEFERRABLE INITIALLY DEFERRED to align with aggregate-level transaction.

Cycle prevention (HARD):
- Not enforceable with simple constraints; handled in application layer before commit. Optional: a DEFERRABLE constraint trigger could run a DAG check but may be expensive; not recommended for v1 scale if app already enforces.

Indexes:
- Partial unique on parent-child: `create unique index ux_rel_parent_child on relationships(tree_id, parent_id, child_id) where relation_type='PARENT_CHILD';`
- Partial unique on spouses: `create unique index ux_rel_spouse_pair on relationships(tree_id, spouse1_id, spouse2_id) where relation_type='SPOUSE';`
- Lookup indexes:
  - `create index ix_rel_child on relationships(tree_id, child_id) where relation_type='PARENT_CHILD';`
  - `create index ix_rel_parent on relationships(tree_id, parent_id) where relation_type='PARENT_CHILD';`
  - `create index ix_rel_spouse on relationships(tree_id, spouse1_id, spouse2_id) where relation_type='SPOUSE';`

## Enforcement Summary (Hard vs Soft)

| Invariant | DB Enforcement | Notes |
|-----------|----------------|-------|
| G1 DAG (no cycles) | Application (soft in DB) | Enforced in service; optional expensive trigger if desired. |
| G2 ≤2 parents | Constraint trigger (deferrable) | Required for HARD; cannot express with simple CHECK/UNIQUE. |
| G3 Edge uniqueness | DB partial unique indexes | Enforced per edge type. |
| G4 Referenced persons exist | FKs | Enforced. |
| G5 Connectivity (no isolated person) | Application (soft) | Checked before persist; not enforced by DB. |
| G6 Root validity | FK deferrable | Enforced on family_trees.root_person_id. |
| G7 Age consistency | Application (soft) | Checked pre-commit. |
| Person name non-empty/len | CHECK | Enforced. |
| Gender enum | CHECK | Enforced. |
| Death after birth | CHECK | Enforced. |
| No self-rel | CHECK | Enforced. |
| Spouse pair uniqueness | Partial unique | Enforced. |

## Tree Reconstruction Support
- Primary traversal tables: `relationships` with indexes on `(tree_id, parent_id)` and `(tree_id, child_id)` enable efficient ancestor/descendant BFS/DFS.
- Persons keyed by `(tree_id, person_id)` for fast hydration of `GenealogyGraph` aggregate.
- Generation computations occur in application logic after loading relevant rows; DB optimized for edge lookups.

## Indexing Strategy (Performance at 500–5,000 nodes)
- **Cluster** (optional) relationships on `(tree_id, parent_id)` to speed descendant traversals.
- **Covering index** `(tree_id, child_id, parent_id)` for ancestor lookups.
- **Unique indexes** as above to guard invariants.
- **Foreign key indexes** are implicit via composites; ensure Postgres creates btree indexes on FK columns used in joins:
  - `(tree_id, person_id)` already PK on persons.
  - For relationships FKs, rely on partial indexes plus PK; consider additional btree `(tree_id, parent_id)` and `(tree_id, child_id)` to aid FK checks and traversals.

## Transactions & Deferrable Constraints
- Use `DEFERRABLE INITIALLY DEFERRED` on FK `family_trees.root_person_id` to allow switching root and reassigning within one transaction.
- Parent-count constraint trigger should be DEFERRABLE to evaluate after all batch inserts (e.g., CSV import) while still blocking violations at commit.

## Notes
- Postgres chosen for mature constraint support, partial indexes, and deferrable triggers—fits the “boring, well-supported” rule.
- Graph DB not required at this scale; relational with proper indexes suffices for DAG invariants and traversals.
